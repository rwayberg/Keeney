require("menu")
require("config")
require("ingame")
require("scores")
require("utils")
require("cloud")
require("bird")
require("cow")
require("player")
require("bullet")
require("hud")
require("gameover")
require("AnAL")
require("sick")
require("steak")

local lg = love.graphics

STATE_MENU, STATE_INGAME, STATE_SCORE, GAME_OVER = 0,1,2,3
gamestates = {[0] = menu, [1] = ingame, [2] = scores, [3] = gameover}

WIDTH = 800
HEIGHT = 480

function love.load()
	loadConfig()
	--check for scores
	highscore.set("highscores.lua", 10, "AAA", 100)
	print(highscore.count())
	--make new scores
	if highscore.count() == 0 then
		print("make new high scores")
		highscore.add("JJJ", 200)
		highscore.add("III", 200)
		highscore.add("HHH", 300)
		highscore.add("GGG", 400)
		highscore.add("FFF", 500)
		highscore.add("EEE", 600)
		highscore.add("DDD", 700)
		highscore.add("CCC", 800)
		highscore.add("BBB", 900)
		highscore.add("AAA", 1000)
		highscore.save()
	end
	
	if not love.filesystem.exists("highscores.lua") or highscore.count == 0 then
		
		--scoreFile = love.filesystem.newFile("highscores.lua")
		--scoreFile:open("a")
		--scoreFile:write("ABC 1000\r\n")
		--scoreFile:write("DEF 2000\r\n")
	end
	menu.enter()
end

function setZoom()
	--local sw = love.graphics.getWidth()/WIDTH/config.scale
	--local sh = love.graphics.getHeight()/HEIGHT/config.scale
	--lg.scale(sw,sh)
end

function love.draw()
	lg.push()
	setZoom()

	gamestates[state].draw()
	lg.pop()
	--scene = lg.newImage("img/background.png")
	--player = lg.newImage("img/cow1.png")
	--cloud = lg.newImage("img/cloud.png")
	--love.graphics.print("Hello World", 400, 300)
	--characterposition = {400, 400}
	
	--lg.draw(scene, lg.getWidth() /2 - scene:getWidth()/2, lg.getHeight()/2 - scene:getHeight()/2)
	
	--local drawn = false
	
	--if not drawn then
	--	lg.draw(player, characterposition[1] - player:getWidth()/2, characterposition[2] - player:getHeight())
	--end
end

function love.update(dt)
	gamestates[state].update(dt)
end

function love.keypressed(k, uni)
	gamestates[state].keypressed(k, uni)
end