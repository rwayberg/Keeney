
ingame = {}

lg = love.graphics

function ingame.enter()
	--Remember that if you make a variable to not name if the same of other files
	state = STATE_INGAME
	movetime = 0
	transtime = 0
	cloudTimer = 0
	cloudSpawnTime = 8
	birdTimer = 0
	birdSpawnTime = 25
	scene = lg.newImage("img/background.png")
	scene2 = lg.newImage("img/background.png")
	--player = lg.newImage("img/player/playerwalk.png")
	cowTimer = 0
	cowSpawnTime = 5
	bgX = 0
	bgY = 0
	--playerSpeed = 0.2
	--animPlayer = newAnimation(player, 250, 250, playerSpeed, 8)
	--animPlayer:setMode("loop")
	bgSpeed_Default = 210
	bgSpeed = 210
	--Might want to create an object table and add a cloud table to it
	--could add a table for the background and move the bg stuff to a new file
	cloudList = {}
	--table.insert(cloudList, cloud.create(15, 20, 2))
	
	--local rand = math.random(5,10)
	--ingame.createClouds(rand)
	ingame.createFirstClouds()
	birdList = {}
	ingame.createBirds(1)
	cowList = {}
	local cowSpawning = false
	player1 = player.create(50, 175, 0.2)
	bulletList = {}
	bulletX = 230
	bulletY = 321
	bulletYOffset = 20
	maxBullets = 5
	ingameHUD = hud.create()
	ingameHUD.lifeCount = player1.lifeStart
	local paused = false
	pauseImg = lg.newImage("img/pause.png")
	pauseSelection = 1
	maxCowSpawnCount = 10
	currentCowSpawnCount = 0
	currentCowSpawnLevel = 1
	maxCowSpawnLevel = 3
	steakList = {}
	steakY = 365
end

function ingame.createFirstClouds()
	local rand = math.random(2, 4)
	for count = 1, rand do
		local randSpeed = math.random(20,50)
		local randX = math.random(0, lg.getWidth())
		local randY = math.random(10, 80)
		table.insert(cloudList, cloud.create(randX, randY, randSpeed))
	end
end

function ingame.createClouds(number)
	--local rand = math.random(5,10)
	
	for count = 1, number do
		local randSpeed = math.random(20, 50)
		local randY = math.random(40, 80)
		table.insert(cloudList, cloud.create(lg.getWidth(), randY, randSpeed))
	end
end

function ingame.createBirds(number)
	for bc = 1, number do
		local randSpeed = math.random(30, 60)
		local randY = math.random(40, 80)
		table.insert(birdList, bird.create(0, randY, randSpeed))
	end
end

function ingame.createCows(number)
	for cc = 1, number do
		currentCowSpawnCount = currentCowSpawnCount + 1
		local newCow = cow.create(lg.getWidth(), 220, bgSpeed)
		if currentCowSpawnLevel < maxCowSpawnLevel and currentCowSpawnCount >= maxCowSpawnCount then
			currentCowSpawnCount = 0
			currentCowSpawnLevel = currentCowSpawnLevel + 1
		end
		newCow:SetLevel(currentCowSpawnLevel)
		table.insert(cowList, newCow)
		--table.insert(cowList, cow.create(lg.getWidth(), 220, bgSpeed))
	end
end

function ingame.createBullet(number)
	for bc = 1, number do
		--local proX =
		local proY = (player1.y + (player1.img:getHeight() / 2)) + bulletYOffset
		--table.insert(bulletList, bullet.create(bulletX, bulletY))
		table.insert(bulletList, bullet.create(bulletX, proY))
	end
end

function ingame.createSteak(posX)
	table.insert(steakList, steak.create(posX, steakY, bgSpeed))
end

function ingame.draw()
	
	ingame.drawBackground()
	ingame.drawClouds()
	ingame.drawBirds()
	ingame.drawCows()
	ingame.drawBullets()
	ingame.drawSteaks()
	player1:draw()
	ingameHUD:draw()
	if paused then
		--lg.draw(pauseImg, lg.getWidth() / 2, lg.getHeight() / 2)
		lg.draw(pauseImg, 0, 0)
		lg.print("Paused", (lg.getWidth() / 2) - 60, (lg.getHeight() / 2) - 60)
		if pauseSelection == 1 then
			lg.setColor(255,255,0)
		else
			lg.setColor(255,255,255)
		end
		lg.print("Resume", (lg.getWidth() / 2) - 60, (lg.getHeight() / 2) - 10)
		if pauseSelection == 2 then
			lg.setColor(255,255,0)
		else
			lg.setColor(255,255,255)
		end
		lg.print("Exit", (lg.getWidth() / 2) - 20, (lg.getHeight() / 2) + 20)
		lg.setColor(255,255,255)
	end
--	ingame.drawPlayer()
end

function ingame.drawBackground()
	lg.push()
	
	--scene = lg.newImage("img/background.png")
	local sw = lg.getWidth()/ scene:getWidth()
	local sh = lg.getHeight()/ scene:getHeight()
	--lg.draw(menuscene,  lg.getWidth() / 2 - menuscene:getWidth() / 2 * sw, lg.getHeight() / 2 - menuscene:getHeight() / 2 * sh, 0, sw, sh)
	local x = lg.getWidth() / 2 - scene:getWidth() / 2 * sw
	local y = lg.getHeight() / 2 - scene:getHeight() / 2 * sh
	
	if x + bgX > lg.getWidth() then
		bgX = 0
	end
	lg.draw(scene, x - bgX, y - bgY, 0, sw, sh)
	
	local s2xOffset = scene:getWidth()
	local s1X = x + scene:getWidth() * sw
	--local s1Y = y + 
	lg.draw(scene2, s1X - bgX, y, 0, sw, sh) 
	
	--lg.print((x - bgX), 400, 300)
	
	lg.pop()
end

function ingame.drawClouds()
	for dc=1,#cloudList,1 do
		lg.push()
		cloudList[dc]:draw()
		lg.pop()
	end
end

function ingame.drawBirds()
	for i=1,#birdList,1 do
		birdList[i]:draw()
	end
end

function ingame.drawCows()
	for i=1,#cowList,1 do
		cowList[i]:draw()
	end
end

function ingame.drawBullets()
	for i=1,#bulletList,1 do
		bulletList[i]:draw()
	end
end

function ingame.drawSteaks()
	for i=1,#steakList,1 do
		steakList[i]:draw()
	end
end

--function ingame.playerUpdate(dt)
--	animPlayer:update(dt)
--end

function ingame.moveBackground(dt)
	bgX = bgX + (bgSpeed * dt)
end

function ingame.updateclouds(dt)
--ingame.playerUpdate(dt)
		--update or remove clouds
		for i=#cloudList,1,-1 do
			if cloudList[i].offScreen == true then
				table.remove(cloudList, i)
			end
		end
		--add new clouds
		cloudTimer = cloudTimer + dt
		local cSpawnRand = math.random(0, 10)
		if #cloudList < 10 and cloudTimer >= cloudSpawnTime and cSpawnRand == 4 then
			ingame.createClouds(1)
			cloudTimer = 0
		end
		for c=1,#cloudList,1 do
			cloudList[c]:update(dt)
		end
end

function ingame.updatebirds(dt)
--bird update and remove
		birdTimer = birdTimer + dt
		if #birdList < 2 and cSpawnRand == 5 and birdTimer >= birdSpawnTime then
			ingame.createBirds(1)
			birdTimer = 0
		end

		for b=#birdList,1,-1 do
			if birdList[b].offScreen == true then
				table.remove(birdList, b)
			else
				birdList[b]:update(dt)
			end
		end
end

function ingame.updatecows(dt)
--cow update and remove
		cowTimer = cowTimer + dt
		if cowTimer >= cowSpawnTime then
			ingame.createCows(1)
			cowTimer = 0
			if cowSpawnTime > 1 then
				cowSpawnTime = cowSpawnTime - 0.2
			else
				cowSpawnTime = 1
			end
		end

		if #cowList > 0 then
			for cl=#cowList,1,-1 do
				--if cowList[cl].offScreen == true then
				if cowList[cl].dead_remove == true then --or cowList[cl].offScreen == true then
					--table.remove(cowList, cl)
					--ingameHUD:addScore(cowList[cl].score)
					--print("get point " .. cowList[cl].score)
					local randNum = math.random(1, 2)
					print("steak " .. randNum)
					if randNum == 1 then
						print("create steak at " .. cowList[cl].x)
						ingame.createSteak(cowList[cl].x + 75)
					end
					table.remove(cowList, cl)
					--cowList[cl]:update(dt)
				elseif cowList[cl].offScreen == true then
					table.remove(cowList, cl)
				else
					cowList[cl]:update(dt)
				end
			end
		end
end

function ingame.updatebullets(dt)
--Update bullets
		for bulletNumber=#bulletList,1,-1 do
			if bulletList[bulletNumber].offScreen == true then
				table.remove(bulletList, bulletNumber)
			else
				bulletList[bulletNumber]:update(dt)
			end
		end

		--Check bullet collisions
		for bulletNumber=#bulletList,1,-1 do
			local bulletBox = bulletList[bulletNumber]:getBBox()
			for cowNumber=#cowList,1,-1 do
				local cowBox = cowList[cowNumber]:getBBox()
				if CheckCollision(bulletBox.x, bulletBox.y, bulletBox.w, bulletBox.h, cowBox.x, cowBox.y, cowBox.w, cowBox.h) then
					print("Bullet hit cow")
					--ingameHUD:addScore(100)
					--cowList[cowNumber].offScreen = true
					cowList[cowNumber]:hit()
					if cowList[cowNumber].hp == 0 then
						ingameHUD:addScore(cowList[cowNumber].score)
					end
					bulletList[bulletNumber].offScreen = true
				end
			end
		end
end

function ingame.updatesteaks(dt)
	for steakNumber=#steakList,1,-1 do
		if steakList[steakNumber].offScreen == true then
			print("remove steak " .. steakNumber)
			table.remove(steakList, steakNumber)
		else
			--print("update steak #" .. steakNumber)
			steakList[steakNumber]:update(dt)
		end
	end
end

function ingame.updateplayer(dt)
	local pBB = player1:getBBox()
	for steakBB=#steakList,1,-1 do
			local sBB = steakList[steakBB]:getBBox()
			if CheckCollision(pBB.x, pBB.y, pBB.w, pBB.h, sBB.x, sBB.y, sBB.w, sBB.h) then
				print("steak pickup")
				steakList[steakBB].offscreen = true
				table.remove(steakList, steakNumber)
				ingameHUD:addSteak(1)
			end
		end
--Check player collisions ax1,ay1,aw,ah, bx1,by1,bw,bh
		for cowBB=#cowList,1,-1 do
			local cBB = cowList[cowBB]:getBBox() 
			--player death
			if CheckCollision(pBB.x, pBB.y, pBB.w, pBB.h, cBB.x, cBB.y, cBB.w, cBB.h) then
				ingameHUD:removeLife(1)
				player1.lifeCount = ingameHUD.lifeCount
				player1.score = ingameHUD.score
				player1.steakcount = ingameHUD.steakCount
				cowList[cowBB].offScreen = true
				--reset cow spawning
				if(currentCowSpawnLevel > 1) then
					currentCowSpawnLevel = currentCowSpawnLevel - 1
				end
				currentCowSpawnCount = 0
				cowSpawnTime = cowSpawnTime + 0.4
				--print("Player hit a cow!")
				player1:collide()
				for b in pairs(bulletList) do
					bulletList[b] = nil
				end
			end
		end
end

function ingame.update(dt)
	if not paused then
		ingame.moveBackground(dt)
		player1:update(dt)
		--stop because player was hit
		ingame.updateclouds(dt)
		ingame.updatebirds(dt)
		if player1.hit then
			bgSpeed = 0
		else
			--if bgSpeed == 0 and ingameHUD.lifeCount > 0 then
			if bgSpeed == 0 then
				print("stopped")
				if player1.lifeCount > 0 then
					bgSpeed = bgSpeed_Default
				--else
					--game over screen
					--gameover.enter()
				end
			end
			ingame.updatecows(dt)
			ingame.updatebullets(dt)
			ingame.updatesteaks(dt)
			ingame.updateplayer(dt)
		end
	else
		--paused 
	end
end

function ingame.keypressed(k, uni)
	print("Pressed " .. k)
	if not paused then
		if k == "rctrl" then
			if not player1.hit and #bulletList <= maxBullets then
				ingame.createBullet(1)
			end
		elseif k == " " then
			player1:jump()
		elseif k == "escape" then
			if paused then
				paused = false
			else
				paused = true
			end
		end
	else
		if k == "up" then
			pauseSelection = wrap(pauseSelection - 1, 1,2)
		elseif k == "down" then
			pauseSelection = wrap(pauseSelection + 1, 1,2)
		elseif k == "return" then
		--1 = resume, 2 == exit
			if pauseSelection == 1 then
				paused = false
			elseif pauseSelection == 2 then
				paused = false
				menu.enter()
			end
		end
		print("pause menu " .. pauseSelection)
	end
end

